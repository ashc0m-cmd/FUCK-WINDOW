chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed');
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const actions = {
    getConfig: () => {
      chrome.storage.sync.get(['config'], (data) => {
        sendResponse(data.config);
      });
      return true; // Keep message channel open
    },
    log: () => {
      if (msg.data && msg.data.length > 0) {
        console.log('[LOG]', msg.data);
      }
    },
    openTab: () => {
      chrome.tabs.create({ url: msg.url });
    }
  };

  if (actions[msg.type]) return actions[msg.type]();
});
function updatePreview(config) {
  const preview = document.querySelector('.preview-card');
  if (!preview) return;

  preview.style.backgroundColor = getComputedStyle(document.documentElement)
    .getPropertyValue('--bg-color');
  preview.style.color = getComputedStyle(document.documentElement)
    .getPropertyValue('--text-color');
  preview.style.borderColor = getComputedStyle(document.documentElement)
    .getPropertyValue('--accent-color');

  preview.querySelector('.preview-title').textContent = config.title || 'Preview Title';
  preview.querySelector('.preview-description').textContent = config.description || 'Description goes here.';
}